// src/App.tsx
import * as React from 'react'
import { useFish, usePond, useRegistryFish } from '@actyx-contrib/react-pond' // add import
import { createRegistryFish } from '@actyx-contrib/registry'
import { MaterialRequestFish } from './materialRequestFish' // import the fish

const MaterialRequestRegistryFish = createRegistryFish(
  MaterialRequestFish, // entity to register
  'placed', // add fish on placed event,
  'finished', // remove fish on finished event
)

export const App = () => {
  const [matReqFish, setMatReqId] = useFish(MaterialRequestFish) // add useFish
  const [materialRequests] = useRegistryFish(
    MaterialRequestRegistryFish, MaterialRequestFish
  )
  const pond = usePond()
  return (
    <div>
    {/* button to place a random material request */}
      <button
        onClick={() => {
            const randomID = Math.round(Math.random() * 9999999)
            // feed the random MaterialRequestFish with the place command
            pond.feed(MaterialRequestFish, `ID:${randomID}`)({
            type: 'place',
            material: 'something',
            amount: Math.round(Math.random() * 100)
            }).toPromise()
        }}
      >
        Random material request
      </button>
      <br />
      {/* First we add a dropdown list to select the material request */}
      <select onChange={e => setMatReqId(e.target.value)}>
        <option></option> {/*nothing selected*/}
        { // Map each material request to one option
          materialRequests.map(mrq =>
            <option key={mrq.name} value={mrq.name}>
              {/* we also can ad the current state(type) now*/}
              {mrq.name} ({mrq.state.type})
            </option>
          )
        }
      </select>
      {/* We hide the material request UI, as long as no a ID is selected and fish  */}
      {matReqFish && (
        <>
          <h1>Material Request: ({matReqFish.name})</h1>
          <div>Status: {matReqFish.state.type}</div>
          { matReqFish.state.type !== 'undefined' &&
            <div>
              Material: {matReqFish.state.material} {matReqFish.state.amount}pc
            </div>
          }
          <h3>
            <button onClick={() => matReqFish.feed({type: 'started'})}>
              start
            </button>
            <button onClick={() => matReqFish.feed({type: 'finished'})}>
              finish
            </button>
          </h3>
        </>
      )}
    </div>
  )
}