// src/materialRequestFish.ts
import { FishType, OnStateChange,
    Semantics, Subscription } from '@actyx/pond'
  
  export type State =
    | { type: 'undefined' }
    | { type: 'idle' | 'started' | 'finished'
        material: string
        amount: number
      }
  
  export type Event =
    | { type: 'placed', material: string, amount: number }
    | { type: 'started' }
    | { type: 'finished' }
  
  export type Command =
    | { type: 'place', material: string, amount: number }
    | { type: 'started' }
    | { type: 'finished' }
  
  const semantics = Semantics.of('com.example.MaterialRequest')
  // MaterialRequestFish Definition
  export const MaterialRequestFish =
    FishType.of<State, Command, Event, State>({
    semantics,
    initialState: name => ({
      state: { type: 'undefined' },
      subscriptions: [Subscription.of(semantics, name)]
    }),
    onEvent: (state, event) => {
      switch(event.payload.type) {
        case 'placed':
          const { material, amount } = event.payload
          return { type: 'idle', material, amount }
        case 'started':
          if (state.type !== 'undefined') {
            state.type = 'started'
          }
          return state
        case 'finished':
          if (state.type === 'started') {
            state.type = 'finished'
          }
          return state
      }
      return state
    },
    onCommand: (state, command) => {
      switch(command.type) {
        case 'place':
          const { material, amount } = command
          return [{ type: 'placed', material, amount }]
        case 'started':
          return state.type === 'idle' ? [{ type: 'started' }] : []
        case 'finished':
          return state.type === 'started' ? [{ type: 'finished' }] : []
      }
      return []
    },
    onStateChange: OnStateChange.publishPrivateState(),
  })